new Masonry(document.getElementById('masonry'),{
    gap:10,
    columns:4
})